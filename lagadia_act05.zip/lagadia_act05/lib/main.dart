import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: Colors.blue, useMaterial3: true),
        home: const StudentForm(),
      );
}

class StudentForm extends StatefulWidget {
  const StudentForm({super.key});
  @override
  State<StudentForm> createState() => _StudentFormState();
}

class _StudentFormState extends State<StudentForm> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _age = TextEditingController();
  final _address = TextEditingController();
  final _contact = TextEditingController();
  final _email = TextEditingController();
  String? _gender;
  Map<String, String>? _submitted;

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'This field is required' : null;

  void _submit() {
    if (_formKey.currentState!.validate()) {
      setState(() => _submitted = {
            'Full Name': _name.text,
            'Age': _age.text,
            'Gender': _gender!,
            'Address': _address.text,
            'Contact Number': _contact.text,
            'Email': _email.text,
          });
    }
  }

  void _clear() {
    _formKey.currentState!.reset();
    for (final c in [_name, _age, _address, _contact, _email]) {
      c.clear();
    }
    setState(() {
      _gender = null;
      _submitted = null;
    });
  }

  Widget _field(String label, TextEditingController c,
      {TextInputType? type, String? Function(String?)? validator}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c,
        keyboardType: type,
        decoration:
            InputDecoration(labelText: label, border: const OutlineInputBorder()),
        validator: validator ?? _required,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Profile Form')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Form(
            key: _formKey,
            child: Column(children: [
              _field('Full Name', _name),
              _field('Age', _age, type: TextInputType.number, validator: (v) {
                if (v == null || v.isEmpty) return 'This field is required';
                final n = int.tryParse(v);
                return (n == null || n < 1 || n > 120) ? 'Enter a valid age' : null;
              }),
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: DropdownButtonFormField<String>(
                  initialValue: _gender,
                  decoration: const InputDecoration(
                      labelText: 'Gender', border: OutlineInputBorder()),
                  items: ['Male', 'Female', 'Other']
                      .map((g) => DropdownMenuItem(value: g, child: Text(g)))
                      .toList(),
                  onChanged: (v) => setState(() => _gender = v),
                  validator: (v) => v == null ? 'Please select gender' : null,
                ),
              ),
              _field('Address', _address),
              _field('Contact Number', _contact, type: TextInputType.phone,
                  validator: (v) {
                if (v == null || v.isEmpty) return 'This field is required';
                return RegExp(r'^\d{7,15}$').hasMatch(v)
                    ? null
                    : 'Enter a valid number (7-15 digits)';
              }),
              _field('Email', _email, type: TextInputType.emailAddress,
                  validator: (v) {
                if (v == null || v.isEmpty) return 'This field is required';
                return RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v)
                    ? null
                    : 'Enter a valid email';
              }),
              Row(children: [
                Expanded(
                    child: FilledButton(
                        onPressed: _submit, child: const Text('Submit'))),
                const SizedBox(width: 12),
                Expanded(
                    child: OutlinedButton(
                        onPressed: _clear, child: const Text('Clear'))),
              ]),
            ]),
          ),
          if (_submitted != null)
            Card(
              margin: const EdgeInsets.only(top: 20),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Submitted Information',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const Divider(),
                    for (final e in _submitted!.entries)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Text('${e.key}: ${e.value}'),
                      ),
                  ],
                ),
              ),
            ),
        ]),
      ),
    );
  }
}