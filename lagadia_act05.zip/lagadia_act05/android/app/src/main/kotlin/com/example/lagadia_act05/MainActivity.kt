package com.example.lagadia_act05

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
